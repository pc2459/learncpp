/********

Name: Chia, Po Linn
Date: 2014-07-15
Homework #: Lab 5

See main.cpp for sources &c.

*********/

#include "city.h"

City::City(){
	name = "";
	msg = "";
	prev = NULL;
	next = NULL;

}

City::~City(){

}